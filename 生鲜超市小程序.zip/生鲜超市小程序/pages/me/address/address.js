const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {},
  onShow() {
    this.getUser()
    let address = wx.getStorageSync('address')
    this.setData({
      address,
    })
    console.log("aaa")

    console.log(address)
    if (address) {
      this.setData({
        phone: address.phone,
        name: address.name,
        id: address.id,
        address: address.address + " " + address.addressInfo
      })
    }
  },
  onLoad(options) {
    this.setData({
      order: options.order
    })
  },
  //新增地址
  toAdd() {
    wx.navigateTo({
      url: '/pages/me/address/add/add',
    })
  },
  //获取当前用户地址信息
  getUser() {

    console.log("openid=" + app.globalData.openid)
    wx.cloud.database().collection('sxcs_users').where({
        _openid: app.globalData.openid
      }).get()
      .then(res => {
        console.log(res)
        this.setData({
          user: res.data[0]
        })


      })
  },
  //删除某个地址
  delete(event) {
    var that = this
    var index = event.currentTarget.dataset.index
    var addressList = that.data.user.addressList
    wx.showModal({
        title: '提示',
        content: '确认删除吗',
        confirmText: '确定'
      })
      .then(res => {
        if (res.confirm == true) {
          addressList.splice(index, 1)
          wx.cloud.database().collection('sxcs_users').where({
            _openid: app.globalData.openid
          }).update({
            data: {
              addressList: addressList,


            },
            success(res) {
              console.log(res)

              wx.showToast({
                title: '删除成功',
              })
              that.getUser()



            }

          })
        } else {

        }

      })



  },


  edit(event){
    var that = this
    var index = event.currentTarget.dataset.index
    var addressList = that.data.user.addressList
    app.globalData.add=addressList[index]
    wx.navigateTo({
      url: '/pages/me/address/add/add?edit=1',
    })

  },
  //在订单跳转过来时点击地址才执行此方法
  back(event) {

    var that = this
    //判断是否订单页面跳转
    if (that.data.order != 1) {
      return
    }
    var index = event.currentTarget.dataset.index
    var data = that.data.user.addressList[index]
    wx.setStorageSync('address', data)
    wx.navigateBack({
      success() {
        wx.showToast({
          title: '选择成功',
        })
      }
    })

  },
  choose(event) {
    var index = event.currentTarget.dataset.index
    console.log(index)
    console.log("openid=" + app.globalData.openid)
    wx.cloud.database().collection('sxcs_users').where({
        _openid: app.globalData.openid
      }).get()
      .then(res => {
        console.log(res)
        this.setData({
          user: res.data[0]
        })
        console.log(this.data.user.addressList)

        var shuju = this.data.user.addressList[index]
        console.log(shuju)
    
        wx.setStorageSync('address', shuju)
        var address = shuju
    
    
        wx.showToast({
          title: '已设为默认地址',
        })
        console.log(address)
        if (address) {
          this.setData({
            phone: address.phone,
            name: address.name,
            id: address.id,
            address: address.address + " " + address.addressInfo
          })
        }

      })

  }
})