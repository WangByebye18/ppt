const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    nowIndex: 0,
    location: "请选择位置",
    self2: false

  },
  lableChange: function (e) {
    var t = e.currentTarget.dataset.index;
    this.setData({
      nowIndex: t
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

    this.getUser()
    if (options.edit == 1) {
      this.setData({
        edit: true,
        add: app.globalData.add,
        location: app.globalData.add.address,
        cloudImg: app.globalData.add.image,
        self2: app.globalData.add.xin,

      })
      var address = wx.getStorageSync('address')
      if (app.globalData.add.id == address.id) {
        this.setData({
          self: true
        })
      }

    }
  },
  onShow() {
  
  },

  //获取用户信息
  getUser() {

    console.log("openid=" + app.globalData.openid)
    wx.cloud.database().collection('sxcs_users').where({
        _openid: app.globalData.openid
      }).get()
      .then(res => {
        console.log(res)
        this.setData({
          user: res.data[0]
        })


      })
  },


  // 新增联系人
  submitForm(event) {
    var that = this;

    if (!(event.detail.value.name.replace(/\s+/g, ''))) {
      wx.showToast({
        icon: 'none',
        title: '请填写姓名！',
      })
      return
    }
 
    if (!(event.detail.value.phone.replace(/\s+/g, ''))) {
      wx.showToast({
        icon: 'none',
        title: '请填写联系电话！',
      })
      return
    }
    if (event.detail.value.phone.length != 11) {
      wx.showToast({
        icon: 'none',
        title: '请填写11位的电话！',
      })
      return
    }

  
    var data = {};
    var result = '';

    for (var i = 0; i < 4; i++) {
      result += Math.floor(Math.random() * 10).toString();
    }
    var code = this.data.user.addressId

    data.openid = app.globalData.openid;
    data.id = result
    data.name = event.detail.value.name;

    data.phone = event.detail.value.phone;

    var addressList = this.data.user.addressList
    if(this.data.add){
      for(var i in addressList){
        if(addressList[i].id==this.data.add.id){
          addressList[i]=data
        }
      }

    }else{
      addressList.push(data)

    }
    if (this.data.self) {
      code = result
      wx.setStorageSync('address', data)

    }

    wx.cloud.database().collection('sxcs_users').where({
      _openid: app.globalData.openid
    }).update({
      data: {
        addressList: addressList,
        addressId: code


      },
      success(res) {
        console.log(res)
        wx.navigateBack({
          success() {
            wx.showToast({
              title: '更新成功',
            })
          }
        })

      }

    })
  },

  //选择联系人
  chooseAddress() {
    var that = this;
    wx.chooseLocation({
      success(res) {
        console.log(res)

        that.setData({
          location: res.address + res.name,
          addresssInfo: res
        })

        if (res.address == "") {
          that.setData({
            location: "请选择位置"
          })
        }
      }
    })
  },
  //设置是否为默认联系人
  light(e) {
    //拿到状态
    var status = e.detail.value

    this.setData({
      self: status
    })
  },
  light2(e) {
    //拿到状态
    var status = e.detail.value

    this.setData({
      self2: status
    })
  },
  chooseBigImage() {

    var that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success(res) {
        console.log(res)
        console.log(res.tempFilePaths)
        //上传图片
        that.data.tempImg = res.tempFilePaths[0]
        that.uploadBigImages()
      }
    })
  },
  uploadBigImages() {
    var that = this;

    wx.cloud.uploadFile({
      cloudPath: `actionsImages/${Math.random()}_${Date.now()}.${this.data.tempImg.match(/\.(\w+)$/)[1]}`,
      filePath: this.data.tempImg,
      success(res) {
        console.log(res.fileID)

        that.data.cloudImg = res.fileID
        that.setData({
          cloudImg: that.data.cloudImg

        })
        console.log(that.data.cloudImg)
      }
    })
    console.log(that.data.cloudImg)

  },
  deleteBigImg() {
    this.data.cloudImg = null
    this.setData({
      cloudImg: this.data.cloudImg
    })
  },
  bindPickerChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      index: e.detail.value
    })
  },
})