const app = getApp()
Page({


    data: {

    },
  
    onShow() {
        this.setData({
            userInfo: app.globalData.userInfo
        })
    },
    onLoad: function (options) {
  
    },
    toMyOrder() {
        wx.navigateTo({
            url: '/pages/me/myOders/myOrders',
        })
    },

    login() {
        var that = this;
        // 从数据库查新用户信息
        wx.cloud.database().collection('sxcs_users')
            .where({
                _openid: app.globalData.openid
            })
            .get()
            .then(result => {
                //如果没有数据则跳转添加页面
                if (result.data.length == 0) {
                    wx.navigateTo({
                        url: './userInfo/userInfo',
                        success(){
                            wx.showToast({
                              title: '首次登录请填写用户昵称及头像',
                              icon:'none'
                            })
                        }
                    })
                } else {
                    // 获取数据库用户信息
                    wx.cloud.database().collection('sxcs_users')
                        .where({
                            _openid: app.globalData.openid
                        })
                        .get()
                        .then(res => {
                            console.log(res)
                            app.globalData.userInfo = res.data[0]
                            wx.setStorageSync('userInfo', res.data[0])
                            that.setData({
                                userInfo: res.data[0]
                            })
                        })
                }
            })
    },
    loinOut() {
        app.globalData.userInfo = null
        wx.setStorageSync('userInfo', null)
        this.setData({
            userInfo: null
        })


    },
    toKefu() {
        wx.navigateTo({
            url: '/pages/me/kefu/kefu',
        })
    },
    toFeedback() {
        wx.navigateTo({
            url: '/pages/me/feedback/feedback',
        })
    },

    toCollect() {
        wx.navigateTo({
            url: '/pages/me/collect/collect',
        })
    },
    toYouhui() {
        wx.navigateTo({
            url: '/pages/index/coupon/myCoupon/myCoupon',
        })
    },
    // 跳转编辑页面
    toUserInfo(){
        wx.navigateTo({
          url: './userInfo/userInfo',
        })
    },
    toAddress(){
        wx.navigateTo({
          url: '/pages/me/address/address',
        })
    },
    toMyT(){
        wx.navigateTo({
          url: '/pages/me/tuan/tuan',
        })
    },
    toOrder(){
        wx.navigateTo({
          url: '/pages/me/myOders/myOrders',
        })
    }

})