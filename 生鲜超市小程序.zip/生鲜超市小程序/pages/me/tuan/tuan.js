
const app=getApp()
Page({

    /**
     * 页面的初始数据
     */
    data: {

    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        this.getUser()
       this.getTuan()
    },
    getUser() {
        wx.cloud.database().collection('sxcs_users').where({
                _openid: app.globalData.openid
            }).get()
            .then(res => {
                console.log(res)
                this.setData({
                    user: res.data[0]
                })
            })
    },
    getTuan(){
           wx.cloud.database().collection('sxcs_admin').get()
        .then(res=>{
          console.log(res)
          this.setData({
            list:res.data
          })
        })
    },
    showWindow() {
        var that = this
        this.setData({
            isShow: !this.data.isShow
        })
      
      
      },
      //显示操作栏
      toShow(event) {
        var that = this
        var item = event.currentTarget.dataset.item
        this.setData({
            isShow: true,
            item
        })
      
      
      },
      choose(event){
          var that=this
          var index=event.currentTarget.dataset.index
          var item=that.data.list[index]
        wx.showModal({
            title: '确定选择',
            content: '您要选择'+item.address+'作为您的自提点',
            confirmText: '确定'
          })
          .then(res => {
            if (res.confirm == true) {
                wx.cloud.database().collection('sxcs_users').where({
                    _openid:app.globalData.openid
                  }).update({
                  data:{
                    tuan:item,
         
         
                  },
                  success(res){
                      console.log(res)
                      that.getUser()
                      wx.showToast({
                        title: '切换成功',
                      })
                      that.setData({
                        isShow: false

                      })
                  }
         
          })
            } else {
    
            }
    
          })
      },
      callPhone(){
        wx.makePhoneCall({
          phoneNumber: this.data.user.tuan.phone,
        })
      },
      copy(){
        wx.setClipboardData({
          data: this.data.user.tuan.wx,
        })
      },
      openLocation() {
        var that = this
        wx.openLocation({
            latitude: Number(that.data.user.tuan.latitude),
            longitude: Number(that.data.user.tuan.longitude),
            name:that.data.user.tuan.estate,
            address:that.data.user.tuan.address,
  
        })
    },

    
})