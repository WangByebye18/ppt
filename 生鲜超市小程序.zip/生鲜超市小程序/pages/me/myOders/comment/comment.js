const app = getApp()
const util = require('../../../../utils/util.js')
Page({



  data: {
    choose:-1

  },


  onLoad: function (options) {
    console.log(options.id)

    this.setData({
      goodId:options.id,
      goodName:options.goodName,
      orderId:options.orderId
    })

  },
  getValue(event) {
    console.log(event.detail.value)
    this.data.inputValue = event.detail.value
    this.setData({
        inputValue: (this.data.inputValue).replace(/\s+/g, '')
    })
},
choose(event){
  var index=event.currentTarget.dataset.index
  this.setData({
    choose:index
  })
},
submit(){
    var that=this
    if(!that.data.inputValue){
      wx.showToast({
        title: '请输入评价内容',
        icon:'none'

      })
      return
    }
    if(that.data.choose==-1){
      wx.showToast({
        title: '请打分',
        icon:'none'

      })
      return
    }
    wx.cloud.database().collection('sxcs_comments')
    .add({
      data:{
        score:Number(that.data.choose+1),

        avatarUrl:app.globalData.userInfo.avatarUrl,
        nickName:app.globalData.userInfo.nickName,
        text:this.data.inputValue,
        time:util.formatTime(new Date()),
        goodId:this.data.goodId,
        goodName:this.data.goodName
      }
    })
    .then(res=>{

      //更新订单状态为已完成
      wx.cloud.database().collection('sxcs_orders')
      .doc(this.data.orderId)
      .update({
        data:{
          status:3
        }
      })
      .then(res=>{
        console.log(res)
      })



      wx.navigateBack({
        delta: 0,
        success(){
          wx.showToast({
            title: '提交成功',
          })
        }
      })
    })


  }

  
})