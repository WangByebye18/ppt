const app=getApp()

Page({

  data: {
  
 
    marqueePace: 50,//滚动速度
 
    marqueeDistance: 100,//初始滚动距离
 
    marqueeDistance2: 0,
 
    marquee2copy_status: false,
 
    marquee2_margin: 60,
 
    size: 14,
 
    orientation: 'left',//滚动方向
 
    interval: 500 // 时间间隔
  },

  onHide(){
       clearInterval(this.data.interval)
  },
  onUnload(){
    clearInterval(this.data.interval)
},
  onLoad: function (options) {
    this.getInfo()
    //获取轮播图数据库记录
    this.getBanners()

    //获取分类
    this.getTypeList()
    this.getGoodsList()

    
  },
  getInfo(){
    wx.cloud.database().collection('sxcs_info')
   
    .get()
    .then(res=>{
      this.setData({
        text:res.data[0].gonggao
      })

    })
  },

  onShow: function () {
    return
    // 页面显示
    var vm = this;
    var length = vm.data.text.length * vm.data.size;//文字长度
    var windowWidth = wx.getSystemInfoSync().windowWidth;// 屏幕宽度
    vm.setData({
      length: length,
      windowWidth: windowWidth,
      marquee2_margin: length < windowWidth ? windowWidth - length : vm.data.marquee2_margin//当文字长度小于屏幕长度时，需要增加补白
    });
    vm.run1();// 水平一行字滚动完了再按照原来的方向滚动
  },
  run1: function () {
    var vm = this;
    var interval = setInterval(function () {
      if (-vm.data.marqueeDistance < vm.data.length) {
        vm.setData({
          marqueeDistance: vm.data.marqueeDistance - vm.data.marqueePace,
        });
      } else {
        clearInterval(interval);
        vm.setData({
          marqueeDistance: vm.data.windowWidth
        });
        vm.run1();
      }
    }, vm.data.interval);
  },

  toCoupon(){
    //登录拦截
       if(!app.globalData.userInfo){
         wx.switchTab({
           url: '/pages/me/me',
           success(){
             wx.showToast({
               icon:'error',
               title: '请登录',
             })
           }
         })
         return
       }
       wx.navigateTo({
         url: '/pages/index/coupon/coupon',
       })
     },
  //获取轮播图数据库记录
  getBanners(){

    wx.cloud.database().collection('sxcs_banners').get()
    .then(res=>{
      console.log(res)
      this.setData({
        bannerList:res.data
      })
    })


  },
  toBannerDetail(event){
    console.log(event.currentTarget.dataset.id)
    let id = event.currentTarget.dataset.id
    let index = event.currentTarget.dataset.index
    if(index==0){
      wx.navigateTo({
        url: '/pages/index/coupon/coupon',
      })
      return
    }

    wx.navigateTo({
      url: '/pages/index/bannerDetail/bannerDetail?id=' + id ,
    })
  },
  getTypeList(){
    wx.cloud.database().collection('sxcs_types')
    .where({
      isShowOnHome:true
    })
    .get()
    .then(res=>{
      console.log(res)
      this.setData({
        typeList:res.data
      })
    })
  },
  getGoodsList(){

    wx.cloud.database().collection('sxcs_goods')
    .where({
      status:true,
      stockNumber:wx.cloud.database().command.gt(0)//库存数量必须大于0
    })
    .get()
    .then(res=>{
      console.log(res)
      this.setData({
        goodsList:res.data
      })
    })

  },
  toGoodDetail(event){
    console.log(event.currentTarget.dataset.id)
    let id = event.currentTarget.dataset.id
    wx.navigateTo({
      url: '/pages/goodDetail/goodDetail?id=' + id ,
    })
  },
  toTypeDetail(event){
    console.log(event.currentTarget.dataset.id)
    let id = event.currentTarget.dataset.id
    wx.navigateTo({
      url: '/pages/index/typeDetail/typeDetail?id=' + id,
    })

  },
  toSearch(){
    wx.navigateTo({
      url: '/pages/index/search/search',
    })
  },
  addCart(event){
    var item=event.currentTarget.dataset.item
    //登录拦截
    if(!app.globalData.userInfo){
      wx.switchTab({
        url: '/pages/me/me',
        success(){
          wx.showToast({
            icon:'error',
            title: '请登录',
          })
        }
      })
      return
    }

    let cartList = app.globalData.cartList
    let index = -1
    if(cartList.lengh == 0){
     item.number = 1
      //默认是选中状态
     item.choose = true
      app.globalData.cartList.push(item)
      wx.setStorageSync('cartList', app.globalData.cartList)
    }else{
      for(let idx in cartList){
        console.log(idx)
        if(cartList[idx]._id ==item._id){
          index = idx
        }
      }
      if(index != -1){
        //库存判断
        if(cartList[index].number + 1 >item.stockNumber){
          wx.showToast({
            icon:'error',
            title: '库存不足',
          })
          return
        }
        cartList[index].number =  cartList[index].number + 1
        app.globalData.cartList = cartList
        wx.setStorageSync('cartList', app.globalData.cartList)
      }else{
       item.number = 1
        //默认是选中状态
       item.choose = true
        app.globalData.cartList.push(item)
        wx.setStorageSync('cartList', app.globalData.cartList)
      }
    }

    wx.showToast({
      title: '添加成功！',
    })
    this.setData({
      cartList: app.globalData.cartList
    })
    
    
  },
  toType(event){
    var index=event.currentTarget.dataset.index
    console.log(index)
    if(index==1){
       //登录拦截
       if(!app.globalData.userInfo){
        wx.switchTab({
          url: '/pages/me/me',
          success(){
            wx.showToast({
              icon:'error',
              title: '请登录',
            })
          }
        })
        return
      }
      wx.cloud.database().collection('sxcs_users').where({
        _openid: app.globalData.openid
    }).get()
    .then(res => {
        console.log(res)
        this.setData({
            user: res.data[0]
        })
       if(!this.data.user.address){
        wx.navigateTo({
          url: '/pages/me/userInfo/userInfo',
          success(){
            wx.showToast({
              title: '请填写地址信息',
              icon:'none'
            })
          }
        })
        return
       }else{
        wx.switchTab({
          url: '/pages/type/type',
        })
       }
  
  
    })
    }else{
      wx.switchTab({
        url: '/pages/type/type',
      })
    }
   
    
  },
     
  
})