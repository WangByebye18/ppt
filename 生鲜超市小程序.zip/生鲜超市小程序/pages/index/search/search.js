const app=getApp()
Page({


  data: {
       inputValue:""
  },


  onLoad: function (options) {

  },
  getValue(event){
    console.log(event.detail.value)
    let inputValue = event.detail.value
    this.setData({
      inputValue:inputValue.replace(/\s+/g, '')
    })
    if(this.data.inputValue!=null){
      this.search()

    }

  },
  search(){
    if(!this.data.inputValue){
      return
    }
    wx.cloud.database().collection('sxcs_goods').where({
      title: wx.cloud.database().RegExp({
        regexp: this.data.inputValue,
        options:'i'
      }),
      status:true,
      stockNumber:wx.cloud.database().command.gt(0)//库存数量必须大于0
    }).get()
    .then(res=>{
      console.log(res)
      this.setData({
        goodList:res.data
      })
    })
  },
  toGoodDetail(event){
    console.log(event.currentTarget.dataset.id)
    let id = event.currentTarget.dataset.id
    wx.navigateTo({
      url: '/pages/goodDetail/goodDetail?id=' + id ,
    })
  },
  addCart(event){
    var item=event.currentTarget.dataset.item
    //登录拦截
    if(!app.globalData.userInfo){
      wx.switchTab({
        url: '/pages/me/me',
        success(){
          wx.showToast({
            icon:'error',
            title: '请登录',
          })
        }
      })
      return
    }


    let cartList = app.globalData.cartList
    let index = -1
    if(cartList.lengh == 0){
     item.number = 1
      //默认是选中状态
     item.choose = true
      app.globalData.cartList.push(item)
      wx.setStorageSync('cartList', app.globalData.cartList)
    }else{
      for(let idx in cartList){
        console.log(idx)
        if(cartList[idx]._id ==item._id){
          index = idx
        }
      }
      if(index != -1){
        //库存判断
        if(cartList[index].number + 1 >item.stockNumber){
          wx.showToast({
            icon:'error',
            title: '库存不足',
          })
          return
        }
        cartList[index].number =  cartList[index].number + 1
        app.globalData.cartList = cartList
        wx.setStorageSync('cartList', app.globalData.cartList)
      }else{
       item.number = 1
        //默认是选中状态
       item.choose = true
        app.globalData.cartList.push(item)
        wx.setStorageSync('cartList', app.globalData.cartList)
      }
    }

    wx.showToast({
      title: '添加成功！',
    })
    this.setData({
      cartList: app.globalData.cartList
    })
    
    
  },
  
})