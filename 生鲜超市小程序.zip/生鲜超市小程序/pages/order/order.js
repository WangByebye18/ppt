const app =getApp()
const util = require('../../utils/util.js')
Page({

  data: {
    discount:0,
    self:true,
  },

  onShow(){

    // if(app.globalData.orderList.length<10){
    //   wx.navigateBack({
    //     delta: 0,
    //     success(){
    //       wx.showToast({
    //         icon:'error',
    //         title: '数量小于10',
    //       })
    //     }
    //   })
    // }

    console.log(app.globalData.orderList)
    this.setData({
      orderList:app.globalData.orderList
    })
    this.total()
    this.getMyCoupon()

    //读取缓存里的地址
    let address = wx.getStorageSync('address')
    console.log(address)
    this.setData({
      phone:address.phone,
      name:address.name,
      address:address.provinceName + address.cityName + address.countyName + address.detailInfo
    })
    this.getUser()
  },
  myT(){
    wx.navigateTo({
      url: '/pages/me/tuan/tuan',
    })
  },
  getUser() {

    console.log("openid=" + app.globalData.openid)
    wx.cloud.database().collection('sxcs_users').where({
            _openid: app.globalData.openid
        }).get()
        .then(res => {
            console.log(res)
            this.setData({
                user: res.data[0]
            })
     

        })
},
  add(event){
    console.log(event.currentTarget.dataset.index)
    let index = event.currentTarget.dataset.index

    //库存判断
    if(this.data.orderList[index].number + 1 > this.data.orderList[index].stockNumber){
      wx.showToast({
        icon:'error',
        title: '库存不足',
      })
      return
    }
    
    this.data.orderList[index].number = this.data.orderList[index].number + 1
    //console.log(this.data.orderList)
    this.setData({
      orderList: this.data.orderList
    })


    //计算合计
    this.total()
    this.getMyCoupon()

  },
  reduce(event){

    console.log(event.currentTarget.dataset.index)
    let index = event.currentTarget.dataset.index
    if(this.data.orderList[index].number != 1){
      this.data.orderList[index].number = this.data.orderList[index].number - 1
    }else{
      wx.showToast({
        title: '当前数量已经不能减少了',
        icon:'none'
      })
    }
    this.setData({
      orderList: this.data.orderList
    })

    this.getMyCoupon()

    //计算合计
    this.total()
  },
  //计算合计价格
  total(){
    let sum = 0;
    let totalNumber = 0
    for(let index in this.data.orderList){

      sum = sum + this.data.orderList[index].price * this.data.orderList[index].number
      
      totalNumber = totalNumber + this.data.orderList[index].number


    }
    this.setData({
      sum: sum.toFixed(2),
      totalNumber
    })


  },
  addAddress(){
    let that = this;
    wx.navigateTo({
      url: '/pages/me/address/address?order=1',
    })

  },
  getNote(event){
    console.log(event.detail.value)
    this.setData({
      note:event.detail.value
    })
  },
  addOrder(){
    var that=this
    if(!that.data.name){
      wx.navigateTo({
        url: '/pages/me/userInfo/userInfo',
        success(){
          wx.showToast({
            title: '请选择地址信息',
            icon:'none'
          })
        }
      })
      return
   
    }
    if(!that.data.user.tuan){
      wx.navigateTo({
        url: '/pages/me/tuan/tuan',
        success(){
          wx.showToast({
            title: '请选择自提点',
            icon:'none'
          })
        }
      })
      return
   
    }
    console.log(util.formatTime(new Date))
    var result = '';
    for(var i = 0; i< 4; i++) {
    result += Math.floor(Math.random() * 10).toString();
    }
    console.log(result)

    wx.cloud.database().collection('sxcs_orders').add({
      data:{
        name:that.data.name,
        tuan:that.data.user.tuan,
        tuanId:that.data.user.tuan._id,
        phone:that.data.phone,
 

        goods:this.data.orderList,
        totalMoney:Number(this.data.sum-this.data.discount),
        time:util.formatTime(new Date),
        note:this.data.note,
        status: Number(-1),
        //-2: 取消订单
        //-1：待支付
        // 0: 待发货
        // 1：待收货 +已发货 ；
        // 2：待评价 ；
        // 3：已完成
      }
    }).then(res=>{
      console.log(res._id)
      
     
      let orderId = res._id
      this.setData({
        orderId
      })
       //调起微信支付
      if(that.data.discount!=0){

        console.log("憨憨吧")
        console.log(that.data.list[that.data.index]._id)

        wx.cloud.database().collection('sxcs_couponRecord').doc(that.data.list[that.data.index]._id)
        .update({
          data:{
            status:"1"
          }
        })
        .then(result=>{
          console.log(result)
         
          
          //调起虚拟支付
          this.xuniPay()
         
        })
      }else{
        //调起微信支付
        // this.pay()
        
        //调起虚拟支付
        this.xuniPay()
      }
     

    

    })

  },
  xuniPay(){
    let that = this;
    
    wx.showModal({
      title: '提示',
      content: '是否确认支付？',
      success(res) {
        if (res.confirm) {
          wx.cloud.database().collection('sxcs_orders').doc(that.data.orderId)
          .update({
            data:{
              status:Number(0)
            }
          })
          .then(result=>{
            console.log(result)
  
            //从购物车里面清除购物车里面的商品
            that.clearCartList()
  
            //添加商品销量  减去对应库存数量
            that.addSaleNumber()
  
            wx.navigateBack({
              delta: 0,
              success(){
                wx.showToast({
                  title: '支付成功',
                })
              }
            })
          })
        
         
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
    

      
   
      
    
  },
  clearCartList(){

    for(let i in app.globalData.cartList){

      for(let j in app.globalData.orderList){

        if(app.globalData.orderList[j]._id == app.globalData.cartList[i]._id){
          app.globalData.cartList.splice(i,1)
        }

      }

    }
    wx.setStorageSync('cartList', app.globalData.cartList)


  },
  //添加商品销量  减去对应库存数量
  addSaleNumber(){

    for(let l in app.globalData.orderList){

      wx.cloud.database().collection('sxcs_goods')
      .doc(app.globalData.orderList[l]._id)
      .update({
        data:{
          saleNumber:wx.cloud.database().command.inc(app.globalData.orderList[l].number),
          stockNumber:wx.cloud.database().command.inc(-app.globalData.orderList[l].number)
        }
      })
      .then(res=>{
        console.log(res)
      })

    }

  },

  getMyCoupon(){
    var nowDate=util.formatTime(new Date())
    wx.cloud.database().collection('sxcs_couponRecord').where({
        status:"0",
        _openid:app.globalData.openid
    }).get()
    .then(res=>{
        console.log(res)
        var recordList=res.data
        var list=[]
            for(var i in recordList){
                recordList[i].choose=false
                var expirationTime=recordList[i].coupon.expirationTime
                var cha=new Date(nowDate)-new Date(expirationTime)
                console.log(cha)
              if(cha<=0&&recordList[i].coupon.minMoney<=this.data.sum){
                   list.push(recordList[i])
              }
            }
            this.setData({
                list:list
            })
        
    })
  },
  chooseCoupon(event){
    console.log(event.currentTarget.dataset.index)
    let index = event.currentTarget.dataset.index
    this.data.list[index].choose = !this.data.list[index].choose
    for(var i in this.data.list){
      if(i!=index&& this.data.list[index].choose==true){
        this.data.list[i].choose=false
      }
    }
    if(this.data.list[index].choose==true){
      this.setData({
        index:index
      })
      this.data.discount=0

      this.data.discount=this.data.discount+this.data.list[index].coupon.reduceMoney
    }
    if(this.data.list[index].choose==false){
      this.data.discount=0
    }
    this.setData({
      discount:this.data.discount,
      list: this.data.list
    })
    
  },

  getAddress(event){
    console.log(event.detail.value)
    this.setData({
      address:event.detail.value
    })
  },
  getName(event){
    console.log(event.detail.value)
    this.setData({
      name:event.detail.value
    })
  },
  getPhone(event){
    console.log(event.detail.value)
    this.setData({
      phone:event.detail.value
    })
  },

  buy(){
    
      wx.showLoading({
        title: '支付中',
        mask:'true'
      })
      var that = this;
      
      //订单号
      var orderNum = Date.now() + Math.floor(9*Math.random()) + ''
      that.setData({
        orderNum:orderNum
      })

      //测试 虚拟支付
      // that.addOrder()
      // return

      //支付模块*******************************
      wx.cloud.callFunction({
        name: 'shop_pay',
        data: {
          msg: '订单',
          outTradeNo: orderNum,
          //new Date().getTime() 或者 Date.now()
          //Date.now() + Math.floor(9*Math.random()) + ''
          //Number((that.data.class.price*100).toFixed(0))  这种安全些
          //Number(that.data.class.price)*100
          totalFee: Number((that.data.sum*100).toFixed(0)) //order.pay*100      1
          //Math.floor(that.data.userInform[0].PayMoney*100)
        },
        success(res) {
          console.log('统一下单返回值',res);
          const payment = res.result.res.payment
          console.log('payment',payment)
          that.payOrder(payment)
        }
      })
      //************************************ 
    
    
  },
  //支付
  payOrder(payment) {
    //第一种方式
    //const {timeStamp,nonceStr,signType,paySign} = payment
    var that = this;
    wx.requestPayment({
      //第一种方式
      // timeStamp,
      // nonceStr,
      // package:payment.package,
      // signType,
      // paySign,

      //第二种方式
      ...payment, //报错
      success (res) {
        console.log('支付成功', res)
        // wx.showToast({
        //   title: '支付成功',
        //   duration:4000
        // })
        //更新订单 变成已经支付
        that.xuniPay()
      },
      fail (res) {
        console.log('支付失败', res)
        //跳转到等待买家付款界面
        wx.showToast({
          title: '支付失败',
          icon:'none'
        })
      },
      complete(res){
        console.log('pay complete', res)
      }
    })
  },
  light(e) {
    //拿到状态
    var status = e.detail.value

    this.setData({
      self: status
    })
},
toUserInfo(){
  wx.navigateTo({
    url: '/pages/me/userInfo/userInfo',
  })
}

})  