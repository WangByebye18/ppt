// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  const res = await cloud.cloudPay.unifiedOrder({
    "body": event.msg,//商品简单描述
    "outTradeNo": event.outTradeNo,//商户系统内部订单号，要求32个字符内
    "spbillCreateIp": "127.0.0.1",//终端IP
    "subMchId": "1636732719",//微信支付分配的子商户号
    "totalFee": event.totalFee,//订单总金额，只能为整数
    "envId": "gzt-6gx9jrffb1e5cfab",//接收微信支付异步通知回调的云函数所在的环境 ID
    "functionName": "pay",//接收微信支付异步通知回调的云函数名
    "nonceStr":'5K8264ILTKCH16CQ2502SI8ZNMTM67VS',//随机字符串，不长于32位。推荐随机数生成算法
    "tradeType":"JSAPI",//交易类型
    "openid":wxContext.OPENID
  })

  return { 
    res
  }
}