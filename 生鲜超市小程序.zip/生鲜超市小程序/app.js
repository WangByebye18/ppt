// app.js
App({
  onLaunch() {
    

    wx.cloud.init({
      env:'colin-1grz0o6n72e6ef5b'
    })

    if(wx.getStorageSync('cartList')){
      this.globalData.cartList = wx.getStorageSync('cartList')
    }
    if(wx.getStorageSync('userInfo')){
      this.globalData.userInfo = wx.getStorageSync('userInfo')
    }

    //调用云函数获取用户openid
    wx.cloud.callFunction({
      name:'shop_get_openid'
    }).then(res=>{
      console.log(res.result.openid)
      this.globalData.openid = res.result.openid
    })


  },
  getUserInfo(){
    wx.cloud.database().collection('sxcs_users')
    .where({
      _openid:this.globalData.openid
    })
    .get()
    .then(res=>{
      console.log(res)
      this.globalData.userInfo = res.data[0]
      wx.setStorageSync('userInfo', res.data[0])
    })
  },
  globalData: {
    userInfo: null,

    openid:null,

    //购物车列表
    cartList:[],

    //订单列表  
    orderList:null,
    gonggao:"这是一条公告啊啊啊"

  }
})



// {
//   "pagePath": "pages/add/add",
//   "text": "发布",
//   "iconPath": "/images/add_no.png",
//   "selectedIconPath": "/images/add_yes.png"
// },


// 商品比咖啡多了外卖



// 水果超市生鲜蔬菜小程序开发
// 生鲜超市、社区团购、购物买菜水果小程序