/**
 * 作者：编程小石头
 * 微信：2501902696
 */
const db = wx.cloud.database()
Page({
    data: {
        chartData: {
            categories: [],
            series: []
        },
        opts: {
            touchMoveLimit: 24,
            enableScroll: true,
            xAxis: {
                disableGrid: true,
                scrollShow: true,
                itemCount: 4
            },
        }
    },
    onLoad() {
        db.collection('food').orderBy("sell", "desc")
            .limit(10)
            .get()
            .then(res => {
                console.log('销量排行', res.data)
                let list = res.data
                let names = []
                let sells = []
                list.forEach(item => {
                    names.push(item.name)
                    sells.push(item.sell)
                })
                this.setData({
                    chartData: {
                        categories: names,
                        series: [{
                            name: "成交量排名",
                            data: sells
                        }]
                    }
                })
            })
    }
})