/**
 * 作者：编程小石头
 * 微信：2501902696
 */
const db = wx.cloud.database()
Page({
    data: {
        chartData: {
            categories: [],
            series: []
        },
        opts: {
            touchMoveLimit: 24,
            enableScroll: true,
            xAxis: {
                disableGrid: true,
                scrollShow: true,
                itemCount: 4
            },
        }
    },
    onLoad() {
        wx.cloud.callFunction({
            name: "getOrderList",
            data: {
                action: "money"
            }
        }).then(res => {
            console.log('订单', res.result.data)
            let list = res.result.data
            let months = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, ]
            let sells = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
            list.forEach(item => {
                let num = months.indexOf(item.month)
                if (num > -1) {
                    let sell = sells[num] + parseInt(item.totalPrice)
                    sells[num] = sell
                }

            })
            console.log('sells', sells)
            this.setData({
                chartData: {
                    categories: ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"],
                    series: [{
                        name: "每月销售额~单位元",
                        data: sells
                    }]
                },

            })
        })
    }
})